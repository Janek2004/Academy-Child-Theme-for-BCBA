<?php

add_action( 'show_user_profile', 'extra_user_profile_fields' );
add_action( 'edit_user_profile', 'extra_user_profile_fields' );

function extra_user_profile_fields( $user ) { ?>
<h3><?php _e("User BCBA No.", "blank"); ?></h3>

<table class="form-table">
<tr>
<th><label for="address"><?php _e("Bcba No."); ?></label></th>
<td>
<?php
  $bcba_no = get_user_meta($user->ID,'_themex_bcba_no');
?>
<input type="text" name="user_bcba" id="user_bcba" disabled="disabled" value="<?php echo $bcba_no[0]; ?>" class="regular-text" /><br />
<span class="description"><?php _e("BCBA No cannot be changed."); ?></span>
</td>
</tr>
</table>
<?php }

$args = array(
	'name'          => __( 'Evaluation Success Messages', 'theme_text_domain' ),
	'id'            => 'evaluation-sidebar-id',
	'description'   => '',
        'class'         => '',
	'before_widget' => '',
	'after_widget'  => '',
	'before_title'  => '',
	'after_title'   => '' ); 

register_sidebar( $args ); 
$args = array(
	'name'          => __( 'Evaluation Page Error Messages', 'theme_text_domain' ),
	'id'            => 'evaluation-sidebar-id_1',
	'description'   => '',
        'class'         => '',
	'before_widget' => '',
	'after_widget'  => '',
	'before_title'  => '',
	'after_title'   => '' ); 

register_sidebar( $args ); 



/**
 * Themex User
 *
 * Handles users data
 *
 * @class ThemexUser
 * @author Themex
*/
