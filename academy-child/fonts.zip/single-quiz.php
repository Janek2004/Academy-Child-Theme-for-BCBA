<?php 
error_reporting(0);
get_header(); 

the_post();
ThemexLesson::refresh(ThemexCore::getPostRelations($post->ID, 0, 'quiz_lesson', true), true);
ThemexCourse::refresh(ThemexLesson::$data['course'], true);
$layout=ThemexCore::getOption('lessons_layout', 'right');

if($_POST['lesson_action']=="complete_quiz")
{
$user_id = get_current_user_id();
$course_id=$_POST['course_id'];
$lesson_id=$_POST['lesson_id'];

$meta_key="userAns_".$lesson_id."_".$course_id;
$ques_meta_key="userQues_".$lesson_id."_".$course_id;
unset($_POST['course_action'],$_POST['lesson_action'],$_POST['course_id'],$_POST['lesson_id'],$_POST['nonce'],$_POST['action']);
$meta_value = serialize($_POST);
update_user_meta( $user_id, $meta_key, $meta_value);

$ques_meta_array=serialize(ThemexLesson::$data['quiz']['questions']);
update_user_meta( $user_id, $ques_meta_key, $ques_meta_array);

$result=0;
$ques_counter=0;	
foreach(ThemexLesson::$data['quiz']['questions'] as $ID => $question) {
	$passed=true;
							foreach($question['answers'] as $key => $answer) {
								if((isset($_POST[$ID][$key]) && !isset($answer['result'])) || (isset($answer['result']) && !isset($_POST[$ID][$key]))) {
									$passed=false;
								}
							}
							
							if($passed) {
								$result++;
							}
							
							$ques_counter++;
}


}
if($layout=='left') {
?>
<aside class="sidebar column fourcol">
	<?php get_sidebar('lesson'); ?>
</aside>
<div class="column eightcol last">
<?php } else { ?>
<div class="eightcol column">
<?php } ?>
	<h1><?php the_title(); ?></h1>
	<?php the_content(); ?>
	<div class="quiz-listing">
		<form id="quiz_form" action="<?php the_permalink(); ?>" method="POST">
			<div class="message">
           		<?php if($ques_counter){ echo $result ." Answers are correct out of ".$ques_counter." Questions"; } ?>
				<?php ThemexInterface::renderMessages(ThemexLesson::$data['progress']); ?>
                
			</div>
			<?php 
			$counter=0;
			foreach(ThemexLesson::$data['quiz']['questions'] as $key => $question) {
			$counter++;
			?>
			<div class="quiz-question <?php echo $question['type']; ?>">
				<div class="question-title">
					<div class="question-number"><?php echo $counter; ?></div>
					<h4 class="nomargin"><?php echo themex_stripslashes($question['title']); ?></h4>
				</div>
				<?php ThemexLesson::renderAnswers($key, $question); ?>
			</div>
			<?php } ?>
			<input type="hidden" name="course_action" value="complete_course" />
			<input type="hidden" name="lesson_action" value="complete_quiz" />
			<input type="hidden" name="course_id" value="<?php echo ThemexCourse::$data['ID']; ?>" />
			<input type="hidden" name="lesson_id" value="<?php echo ThemexLesson::$data['ID']; ?>" />
			<input type="hidden" name="nonce" class="nonce" value="<?php echo wp_create_nonce(THEMEX_PREFIX.'nonce'); ?>" />
			<input type="hidden" name="action" class="action" value="<?php echo THEMEX_PREFIX; ?>update_lesson" />
		</form>
	</div>
</div>
<?php if($layout=='right') { ?>
<aside class="sidebar fourcol column last">
	<?php get_template_part('sidebar', 'lesson'); ?>
</aside>
<?php } ?>
<?php get_footer(); ?>