<form role="search" method="GET" action="<?php echo SITE_URL; ?>">
	<input type="text" value="<?php the_search_query(); ?>" name="s" />
</form>