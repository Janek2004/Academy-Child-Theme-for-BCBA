<?php

/*

Template Name: Home Page

*/

?>

<?php get_header(); ?>

<?php 
/*
$attachment_id = get_field('home_page_image');

$size = "full"; // (thumbnail, medium, large, full or custom size)

 

$image = wp_get_attachment_image_src( $attachment_id, $size );

// url = $image[0];

// width = $image[1];

// height = $image[2];



$videoUrl=get_field('home_page_video');

?>

<?php if($videoUrl=="") { ?>

<img src="<?php echo $image[0]; ?>" />

<?php }else{ ?>

<iframe src="//player.vimeo.com/video/50125675" width="1140" height="400" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe> <p><a href="<?php echo get_field('home_page_video'); ?>">Cartoon Forum Toulouse: animated clips</a> from <a href="http://vimeo.com/cartoonmedia">CARTOON</a> on <a href="https://vimeo.com">Vimeo</a>.</p>

<?php }*/ ?>





<?php the_post(); ?>

<?php the_content(); ?>

<?php get_footer(); ?>