<div class="user-links">
	<?php if(ThemexUser::$data['active_user']['profile']['twitter']) { ?><a href="<?php echo ThemexUser::$data['active_user']['profile']['twitter']; ?>" class="twitter" target="_blank" title="Twitter"></a><?php } ?>
	<?php if(ThemexUser::$data['active_user']['profile']['facebook']) { ?><a href="<?php echo ThemexUser::$data['active_user']['profile']['facebook']; ?>" class="facebook" target="_blank" title="Facebook"></a><?php } ?>
	<?php if(ThemexUser::$data['active_user']['profile']['google']) { ?><a href="<?php echo ThemexUser::$data['active_user']['profile']['google']; ?>" class="google" target="_blank" title="Google"></a><?php } ?>
	<?php if(ThemexUser::$data['active_user']['profile']['tumblr']) { ?><a href="<?php echo ThemexUser::$data['active_user']['profile']['tumblr']; ?>" class="tumblr" target="_blank" title="Tumblr"></a><?php } ?>
	<?php if(ThemexUser::$data['active_user']['profile']['linkedin']) { ?><a href="<?php echo ThemexUser::$data['active_user']['profile']['linkedin']; ?>" class="linkedin" target="_blank" title="LinkedIn"></a><?php } ?>
	<?php if(ThemexUser::$data['active_user']['profile']['vimeo']) { ?><a href="<?php echo ThemexUser::$data['active_user']['profile']['vimeo']; ?>" class="vimeo" target="_blank" title="Vimeo"></a><?php } ?>
	<?php if(ThemexUser::$data['active_user']['profile']['flickr']) { ?><a href="<?php echo ThemexUser::$data['active_user']['profile']['flickr']; ?>" class="flickr" target="_blank" title="Flickr"></a><?php } ?>
	<?php if(ThemexUser::$data['active_user']['profile']['youtube']) { ?><a href="<?php echo ThemexUser::$data['active_user']['profile']['youtube']; ?>" class="youtube" target="_blank" title="YouTube"></a><?php } ?>
</div>